from django.contrib import admin
from .models import MessageFeatures, Messages 


admin.site.register([MessageFeatures, Messages])


